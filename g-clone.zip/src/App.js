import './App.css';
import SearchPage from './components/Search/SearchPage';

function App() {
  return (
    <div className="App">
      <SearchPage />
    </div>
  );
}

export default App;
